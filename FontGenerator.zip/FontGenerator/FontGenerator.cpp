#include "stdafx.h"
#include "FontGenerator.h"
#include <QProgressDialog>
#include <QDomDocument>

#include <ft2build.h>
#include <freetype/freetype.h>
#include FT_FREETYPE_H


FontGenerator::FontGenerator(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	QSettings settings(ORGANIZATION_NAME, APPLICATION_NAME);
	ui.symbols->setText(settings.value("codes", " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?-+\\/():;%&`'*#$=[]@^{}_~\"><–—«»“”|абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЧЦШЩЪЫЬЭЮЯ©®").toString());
	ui.fontPath->setText(settings.value("fontPath").toString());
	ui.msdfgenPath->setText(settings.value("msdfgenPath").toString());
	ui.outPath->setText(settings.value("outPath").toString());
	ui.xmlPath->setText(settings.value("xmlPath").toString());

	connect(ui.btnStart, &QPushButton::clicked, this, &FontGenerator::on_btnStart_clicked);
	connect(ui.btnFont, &QPushButton::clicked, [=](bool){ui.fontPath->setText(QFileDialog::getOpenFileName(this, "Путь к шрифту", ui.fontPath->text(), "*.ttf")); });
	connect(ui.btnMSDF, &QPushButton::clicked, [=](bool){ui.msdfgenPath->setText(QFileDialog::getOpenFileName(this, "Путь к msdfgen.exe", ui.fontPath->text(), "*.exe")); });
	connect(ui.btnOut, &QPushButton::clicked, [=](bool){ui.outPath->setText(QFileDialog::getExistingDirectory(this, "Путь к png", ui.outPath->text(), QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks));});
	connect(ui.btnXML, &QPushButton::clicked, [=](bool){ui.xmlPath->setText(QFileDialog::getOpenFileName(this, "Выходной XML", ui.xmlPath->text(), "*.xml")); });
}

FontGenerator::~FontGenerator()
{
	QSettings settings(ORGANIZATION_NAME, APPLICATION_NAME);
	settings.setValue("codes", ui.symbols->toPlainText());
	settings.setValue("fontPath", ui.fontPath->text());
	settings.setValue("msdfgenPath", ui.msdfgenPath->text());
	settings.setValue("outPath", ui.outPath->text());
	settings.setValue("xmlPath", ui.xmlPath->text());
	settings.sync();

}

void FontGenerator::on_btnStart_clicked(bool)
{
	QString	codes	= ui.symbols->toPlainText();
	QProgressDialog	progress("Генератор шрифта", "Отмена", 0, codes.length(), this);
	progress.setWindowModality(Qt::WindowModal);

	//Подключаем FreeType
	FT_Library library;
	FT_Error error = FT_Init_FreeType(&library);
	FT_Face face;
	error = FT_New_Face(library, ui.fontPath->text().toLocal8Bit(), 0, &face);

	//Создаем выходной файл
	QDomDocument doc("fontInfo");
	QDomNode	node	= doc.createProcessingInstruction("xml", "version=\"1.0\" encoding=\"utf-8\"");
	doc.insertBefore(node, doc.firstChild());

	QDomElement root = doc.createElement("fontInfo");
	doc.appendChild(root);
	QDomElement xmlFont = doc.createElement("Font");
	root.appendChild(xmlFont);

	//Выставляем параметры шрифта по букве 'X'
	FT_Load_Char(face, 88, FT_LOAD_NO_SCALE);
	xmlFont.setAttribute("name", face->family_name);
	xmlFont.setAttribute("pxrange", 12);
	xmlFont.setAttribute("ascender", face->ascender);
	xmlFont.setAttribute("descender", face->descender);
	xmlFont.setAttribute("midline", 0.5f*face->glyph->metrics.height);
	xmlFont.setAttribute("texSize", 64);
	xmlFont.setAttribute("count", codes.length());

	//Перебираем все символы
	for(int i = 0; i < codes.length(); i++)
	{
		progress.setValue(i);
		if(progress.wasCanceled())
			break;

		//Берем очередной символ
		int code	= codes.at(i).unicode();
		
		//Запускаем msdfgen
		QStringList	args;
		args << "-font" << ui.fontPath->text();
		args << QString("%1").arg(code);
		args << "-size" << "64" << "64";
		args << "-pxrange" << "12";
		args << "-autoframe";
		args << "-o" << ui.outPath->text() + QString("/%1").arg(code) + ".png";
		//if(QProcess::execute(ui.msdfgenPath->text(), args) != 0)
		//{
		//	QMessageBox::critical(&progress, "Генератор шрифта", QString("Завершено с ошибкой на символе %1").arg(code));
		//	break;
		//}

		//Раз все прошло успешно, пишем в xml
		FT_Error error = FT_Load_Char(face, code, FT_LOAD_NO_SCALE);
		QDomElement	xmlChar	= doc.createElement("char");
		xmlFont.appendChild(xmlChar);

		xmlChar.setAttribute("unicode", code);
		xmlChar.setAttribute("width", face->glyph->metrics.width);
		xmlChar.setAttribute("height", face->glyph->metrics.height);
		xmlChar.setAttribute("horiBearingX", face->glyph->metrics.horiBearingX);
		xmlChar.setAttribute("horiBearingY", face->glyph->metrics.horiBearingY);
		xmlChar.setAttribute("horiAdvance", face->glyph->metrics.horiAdvance);
		
		//Загружаем картинку
		QImage	ch(ui.outPath->text() + QString("/%1").arg(code) + ".png");
		if(ch.format() != QImage::Format_RGB32)
			ch	= ch.convertToFormat(QImage::Format_RGB32);

		//Сохраняем ее в xml
		QByteArray imgArray;
		QBuffer imgBuffer(&imgArray);
		imgBuffer.open(QIODevice::WriteOnly);
		ch.save(&imgBuffer, "PNG", 100);
		QString imgBase64(imgArray.toBase64());

		//QDomElement	subTex	= doc.createElement("subTex");
		//xmlChar.appendChild(subTex);
		xmlChar.setAttribute("texture", imgBase64);
	}

	//Сохраняем xml
	QFile	file(ui.outPath->text() + "/" + ui.xmlPath->text());
	if(!file.open(QFile::WriteOnly))
	{
		QMessageBox::critical(this, "Ошибка создания xml!", QString("Cannot read file %1: %2.").arg(ui.xmlPath->text()).arg(file.errorString()));
		return;
	}

	QTextStream out(&file);
	doc.save(out, 4);

	file.close();

	progress.hide();
	QMessageBox::information(this, "Генератор шрифта", "Готово!");
}
