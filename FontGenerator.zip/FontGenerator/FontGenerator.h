#pragma once

#include <QtWidgets/QWidget>
#include "ui_FontGenerator.h"

class FontGenerator : public QWidget
{
	Q_OBJECT

public:
	FontGenerator(QWidget *parent = Q_NULLPTR);
	virtual ~FontGenerator();

private:
	Ui::FontGeneratorClass ui;
	QString	codes;
	void	on_btnStart_clicked(bool);
};
