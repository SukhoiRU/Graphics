/********************************************************************************
** Form generated from reading UI file 'FontGenerator.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FONTGENERATOR_H
#define UI_FONTGENERATOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FontGeneratorClass
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QPushButton *btnFont;
    QLineEdit *msdfgenPath;
    QPushButton *btnMSDF;
    QLabel *label_3;
    QLineEdit *outPath;
    QPushButton *btnOut;
    QLabel *label_4;
    QLineEdit *xmlPath;
    QPushButton *btnXML;
    QLineEdit *fontPath;
    QLabel *label_2;
    QSpacerItem *verticalSpacer;
    QPushButton *btnStart;
    QLabel *label_5;
    QTextEdit *symbols;

    void setupUi(QWidget *FontGeneratorClass)
    {
        if (FontGeneratorClass->objectName().isEmpty())
            FontGeneratorClass->setObjectName(QStringLiteral("FontGeneratorClass"));
        FontGeneratorClass->resize(455, 403);
        gridLayout = new QGridLayout(FontGeneratorClass);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(FontGeneratorClass);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        btnFont = new QPushButton(FontGeneratorClass);
        btnFont->setObjectName(QStringLiteral("btnFont"));

        gridLayout->addWidget(btnFont, 1, 1, 1, 1);

        msdfgenPath = new QLineEdit(FontGeneratorClass);
        msdfgenPath->setObjectName(QStringLiteral("msdfgenPath"));

        gridLayout->addWidget(msdfgenPath, 3, 0, 1, 1);

        btnMSDF = new QPushButton(FontGeneratorClass);
        btnMSDF->setObjectName(QStringLiteral("btnMSDF"));

        gridLayout->addWidget(btnMSDF, 3, 1, 1, 1);

        label_3 = new QLabel(FontGeneratorClass);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 4, 0, 1, 1);

        outPath = new QLineEdit(FontGeneratorClass);
        outPath->setObjectName(QStringLiteral("outPath"));

        gridLayout->addWidget(outPath, 5, 0, 1, 1);

        btnOut = new QPushButton(FontGeneratorClass);
        btnOut->setObjectName(QStringLiteral("btnOut"));

        gridLayout->addWidget(btnOut, 5, 1, 1, 1);

        label_4 = new QLabel(FontGeneratorClass);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 6, 0, 1, 1);

        xmlPath = new QLineEdit(FontGeneratorClass);
        xmlPath->setObjectName(QStringLiteral("xmlPath"));

        gridLayout->addWidget(xmlPath, 7, 0, 1, 1);

        btnXML = new QPushButton(FontGeneratorClass);
        btnXML->setObjectName(QStringLiteral("btnXML"));

        gridLayout->addWidget(btnXML, 7, 1, 1, 1);

        fontPath = new QLineEdit(FontGeneratorClass);
        fontPath->setObjectName(QStringLiteral("fontPath"));

        gridLayout->addWidget(fontPath, 1, 0, 1, 1);

        label_2 = new QLabel(FontGeneratorClass);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 10, 0, 1, 1);

        btnStart = new QPushButton(FontGeneratorClass);
        btnStart->setObjectName(QStringLiteral("btnStart"));
        btnStart->setMinimumSize(QSize(0, 70));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        btnStart->setFont(font);

        gridLayout->addWidget(btnStart, 9, 1, 1, 1);

        label_5 = new QLabel(FontGeneratorClass);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 8, 0, 1, 1);

        symbols = new QTextEdit(FontGeneratorClass);
        symbols->setObjectName(QStringLiteral("symbols"));

        gridLayout->addWidget(symbols, 9, 0, 1, 1);

        QWidget::setTabOrder(btnStart, fontPath);
        QWidget::setTabOrder(fontPath, msdfgenPath);
        QWidget::setTabOrder(msdfgenPath, btnMSDF);
        QWidget::setTabOrder(btnMSDF, btnOut);
        QWidget::setTabOrder(btnOut, outPath);
        QWidget::setTabOrder(outPath, btnXML);
        QWidget::setTabOrder(btnXML, xmlPath);
        QWidget::setTabOrder(xmlPath, symbols);
        QWidget::setTabOrder(symbols, btnFont);

        retranslateUi(FontGeneratorClass);

        btnStart->setDefault(true);


        QMetaObject::connectSlotsByName(FontGeneratorClass);
    } // setupUi

    void retranslateUi(QWidget *FontGeneratorClass)
    {
        FontGeneratorClass->setWindowTitle(QApplication::translate("FontGeneratorClass", "\320\223\320\265\320\275\320\265\321\200\320\260\321\202\320\276\321\200 \321\210\321\200\320\270\321\204\321\202\320\276\320\262", Q_NULLPTR));
        label->setText(QApplication::translate("FontGeneratorClass", "\320\237\321\203\321\202\321\214 \320\272 \321\210\321\200\320\270\321\204\321\202\321\203", Q_NULLPTR));
        btnFont->setText(QApplication::translate("FontGeneratorClass", "...", Q_NULLPTR));
        btnMSDF->setText(QApplication::translate("FontGeneratorClass", "...", Q_NULLPTR));
        label_3->setText(QApplication::translate("FontGeneratorClass", "\320\237\320\260\320\277\320\272\320\260 \321\201 \320\262\321\213\321\205\320\276\320\264\320\275\321\213\320\274\320\270 png", Q_NULLPTR));
        btnOut->setText(QApplication::translate("FontGeneratorClass", "...", Q_NULLPTR));
        label_4->setText(QApplication::translate("FontGeneratorClass", "\320\222\321\213\321\205\320\276\320\264\320\275\320\276\320\271 xml", Q_NULLPTR));
        btnXML->setText(QApplication::translate("FontGeneratorClass", "...", Q_NULLPTR));
        label_2->setText(QApplication::translate("FontGeneratorClass", "\320\237\321\203\321\202\321\214 \320\272 msdfgen.exe", Q_NULLPTR));
        btnStart->setText(QApplication::translate("FontGeneratorClass", "\320\241\321\202\320\260\321\200\321\202", Q_NULLPTR));
        label_5->setText(QApplication::translate("FontGeneratorClass", "\320\235\320\260\320\261\320\276\321\200 \321\201\320\270\320\274\320\262\320\276\320\273\320\276\320\262", Q_NULLPTR));
        symbols->setHtml(QApplication::translate("FontGeneratorClass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FontGeneratorClass: public Ui_FontGeneratorClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FONTGENERATOR_H
