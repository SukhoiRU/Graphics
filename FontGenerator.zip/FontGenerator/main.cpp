#include "stdafx.h"
#include "FontGenerator.h"
#include <QtWidgets/QApplication>
#include <QProcess>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
	FontGenerator w;
	w.show();
	
	return a.exec();
}
