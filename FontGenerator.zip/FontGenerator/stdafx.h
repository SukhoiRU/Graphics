#include <QtWidgets>

#define ORGANIZATION_NAME "RAA ST"
#define ORGANIZATION_DOMAIN "www.raa-st.com"
#define APPLICATION_NAME "FontGenerator"
